# Donación de Peluches

Este proyecto es una página web para donar y adoptar peluches. Está hecho con
Python, Flask y MySQL.

## ¿Qué se puede hacer?

- Crear una cuenta, iniciar sesión y cerrar sesión.
- Publicar peluches y buscar por su descripción.
- Ver los detalles y adoptar peluches disponibles.
- Editar o borrar las donaciones propias.
- Ver mensajes cuando falta un dato o hay un problema.

## Carpetas y archivos

```text
intento_3_peluches/
├── flask_app/
│   ├── config/
│   │   └── mysqlconnection.py       # Conexión con la base de datos
│   ├── controllers/
│   │   ├── __init__.py
│   │   ├── peluches.py              # Páginas y acciones de peluches
│   │   └── usuarios.py              # Registro e inicio de sesión
│   ├── models/
│   │   ├── peluche.py               # Datos y operaciones de peluches
│   │   └── usuario.py               # Datos y operaciones de usuarios
│   ├── static/
│   │   └── css/
│   │       └── style.css            # Apariencia de las páginas
│   ├── templates/
│   │   ├── autenticar_inicio/
│   │   │   └── index.html           # Registro e inicio de sesión
│   │   ├── errores/
│   │   │   └── base_datos.html      # Mensaje de error de MySQL
│   │   ├── pelis/
│   │   │   ├── buscar.html
│   │   │   ├── detalles.html
│   │   │   ├── editar.html
│   │   │   ├── index.html            # Lista principal de peluches
│   │   │   └── nueva.html
│   │   └── base.html                # Estructura común de las páginas
│   └── __init__.py                  # Crea la aplicación Flask
├── resources/
│   ├── db/
│   │   └── esquema_peluches.sql     # Crea la base de datos y sus tablas
│   └── Captura de pantalla 2026-10-26 125235.png
├── .env.example                     # Ejemplo de configuración
├── .gitignore                       # Archivos que no se deben compartir
├── Pipfile                          # Dependencias para Pipenv
├── README.md                        # Esta guía
├── requirements.txt                 # Dependencias para pip
└── server.py                        # Inicia el sitio
```

Los controladores reciben las acciones de la página. Los modelos trabajan con
los datos. Las plantillas son las páginas HTML y el CSS define su apariencia.

## Preparar el proyecto en Windows

Abre PowerShell en la carpeta del proyecto y ejecuta:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## Preparar la base de datos

Inicia MySQL. Después, ejecuta el esquema desde la carpeta del proyecto:

```powershell
cmd /c "mysql -u root -p < resources\db\esquema_peluches.sql"
```

También puedes abrir `resources/db/esquema_peluches.sql` con MySQL Workbench y
ejecutarlo allí. El esquema crea la base de datos `donacion_peluches` y sus
tablas.

## Configurar la conexión

1. Crea un archivo `.env` copiando el ejemplo:

   ```powershell
   Copy-Item .env.example .env
   ```

2. Abre `.env` y escribe los datos de tu MySQL en `DB_HOST`, `DB_PORT`,
   `DB_USER`, `DB_PASSWORD` y `DB_NAME`.
3. Cambia `SECRET_KEY` por una clave privada. Puedes crear una con:

   ```powershell
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

No compartas el archivo `.env`: contiene datos privados. El `.gitignore` ya
evita que se suba, pero permite compartir `.env.example`.

## Iniciar el sitio

Con MySQL encendido y el archivo `.env` configurado, ejecuta:

```powershell
python server.py
```

Abre <http://127.0.0.1:5000/> en el navegador. Para detener el servidor,
presiona `Ctrl+C` en PowerShell.

## Sobre las pruebas

El proyecto no tiene una carpeta de pruebas automatizadas por ahora.

## Autor

Daniel Rivera — 4to medio, curso C.
