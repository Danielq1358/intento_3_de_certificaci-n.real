CREATE DATABASE IF NOT EXISTS donacion_peluches
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE donacion_peluches;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(80) NOT NULL,
    apellido VARCHAR(80) NOT NULL,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_usuarios_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS peluches (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(120) NOT NULL,
    descripcion TEXT NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    adoptado_por_id INT UNSIGNED NULL,
    visitas INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_peluches_fecha (fecha_creacion),
    CONSTRAINT fk_peluches_donador
        FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT fk_peluches_adoptante
        FOREIGN KEY (adoptado_por_id) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;
