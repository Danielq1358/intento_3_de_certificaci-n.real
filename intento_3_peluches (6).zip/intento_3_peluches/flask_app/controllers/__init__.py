from flask_app.controllers.peluches import peluches
from flask_app.controllers.usuarios import usuarios

__all__ = ["peluches", "usuarios"]
