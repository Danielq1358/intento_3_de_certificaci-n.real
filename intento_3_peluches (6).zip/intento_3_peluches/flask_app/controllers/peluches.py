from functools import wraps

from flask import Blueprint, abort, redirect, render_template, request, session, url_for

from flask_app.models.peluche import Peluche

# Este blueprint agrupa las páginas para publicar y administrar peluches.
peluches = Blueprint("peluches", __name__)


# Protegemos las páginas para que solo entren usuarios con sesión iniciada.
def requiere_sesion(funcion):
    @wraps(funcion)
    def protegida(*args, **kwargs):
        if session.get("usuario_id") is None:
            return redirect(url_for("usuarios.index"))
        return funcion(*args, **kwargs)

    return protegida


@peluches.route("/peluches")
@requiere_sesion
def index():
    return render_template(
        "pelis/index.html",
        peluches=Peluche.listar(),
    )


@peluches.route("/buscar")
@requiere_sesion
def buscar():
    termino = (request.args.get("q") or "").strip()
    return render_template(
        "pelis/buscar.html",
        peluches=Peluche.listar(termino),
        termino=termino,
    )


@peluches.route("/donar", methods=["GET", "POST"])
@requiere_sesion
def nueva():
    if request.method == "POST":
        # Si hay errores, mostramos de nuevo el formulario con lo que escribió la persona.
        errores = Peluche.validar(request.form)
        if errores:
            return render_template(
                "pelis/nueva.html",
                errores=errores,
                valores=request.form,
            ), 400
        peluche_id = Peluche.crear(request.form, session["usuario_id"])
        return redirect(url_for("peluches.detalle", peluche_id=peluche_id))
    return render_template("pelis/nueva.html")


@peluches.route("/peluche/<int:peluche_id>")
@requiere_sesion
def detalle(peluche_id):
    peluche = Peluche.obtener(peluche_id, incrementar_visitas=True)
    if peluche is None:
        abort(404)
    return render_template("pelis/detalles.html", peluche=peluche)


@peluches.route("/peluche/<int:peluche_id>/editar", methods=["GET", "POST"])
@requiere_sesion
def editar(peluche_id):
    peluche = Peluche.obtener(peluche_id)
    if peluche is None:
        abort(404)
    # Cada persona solo puede editar los peluches que publicó.
    if peluche.usuario_id != session["usuario_id"]:
        abort(403)

    if request.method == "POST":
        # Revisamos los datos antes de guardar los cambios.
        errores = Peluche.validar(request.form)
        if errores:
            return render_template(
                "pelis/editar.html",
                peluche=peluche,
                errores=errores,
                valores=request.form,
            ), 400
        Peluche.actualizar(peluche_id, session["usuario_id"], request.form)
        return redirect(url_for("peluches.detalle", peluche_id=peluche_id))
    return render_template("pelis/editar.html", peluche=peluche)


@peluches.route("/peluche/<int:peluche_id>/borrar", methods=["POST"])
@requiere_sesion
def borrar(peluche_id):
    borradas = Peluche.borrar(peluche_id, session["usuario_id"])
    if not borradas:
        abort(404)
    return redirect(url_for("peluches.index"))


@peluches.route("/peluche/<int:peluche_id>/adoptar", methods=["POST"])
@requiere_sesion
def adoptar(peluche_id):
    adoptado = Peluche.adoptar(peluche_id, session["usuario_id"])
    if not adoptado:
        abort(400, description="Este peluche ya fue adoptado o no está disponible.")
    return redirect(url_for("peluches.detalle", peluche_id=peluche_id))
