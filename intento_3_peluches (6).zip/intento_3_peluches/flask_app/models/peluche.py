from flask_app.config.mysqlconnection import connectToMySQL


_MAX_NOMBRE_LENGTH = 120
_MAX_DESCRIPCION_LENGTH = 5000


class Peluche:
    # Guardamos aquí los datos de un peluche y la información de sus usuarios.
    def __init__(self, datos):
        self.id = datos.get("id")
        self.nombre = datos.get("nombre", "")
        self.descripcion = datos.get("descripcion", "")
        self.usuario_id = datos.get("usuario_id")
        self.fecha_creacion = datos.get("fecha_creacion")
        self.adoptado_por_id = datos.get("adoptado_por_id")
        self.visitas = datos.get("visitas", 0)
        self.donador = datos.get("donador")
        self.adoptante = datos.get("adoptante")

    @staticmethod
    def _ejecutar_consulta(consulta, datos=None):
        # Abrimos y cerramos la conexión en el mismo lugar.
        conexion = connectToMySQL()
        try:
            return conexion.query_db(consulta, datos)
        finally:
            conexion.connection.close()

    @staticmethod
    def _limpiar_datos(datos):
        # Quitamos espacios al principio y al final de los textos.
        return {
            "nombre": datos["nombre"].strip(),
            "descripcion": datos["descripcion"].strip(),
        }

    @classmethod
    def listar(cls, termino=""):
        consulta = """
            SELECT p.id, p.nombre, p.descripcion, p.usuario_id, p.fecha_creacion,
                   p.adoptado_por_id, p.visitas,
                   CONCAT(u.nombre, ' ', u.apellido) AS donador,
                   CONCAT(a.nombre, ' ', a.apellido) AS adoptante
            FROM peluches p
            JOIN usuarios u ON u.id = p.usuario_id
            LEFT JOIN usuarios a ON a.id = p.adoptado_por_id
        """
        valores = {}

        # Si se escribió una búsqueda, filtramos por la descripción.
        if termino:
            consulta += " WHERE p.descripcion LIKE %(termino)s"
            valores["termino"] = f"%{termino}%"

        consulta += " ORDER BY p.fecha_creacion DESC, p.id DESC"
        resultados = cls._ejecutar_consulta(consulta, valores)
        return [cls(datos) for datos in resultados]

    @classmethod
    def obtener(cls, peluche_id, incrementar_visitas=False):
        conexion = connectToMySQL()
        try:
            # La visita se suma al abrir el detalle del peluche.
            if incrementar_visitas:
                conexion.query_db(
                    "UPDATE peluches SET visitas = visitas + 1 WHERE id = %(id)s",
                    {"id": peluche_id},
                )

            consulta = """
                SELECT p.id, p.nombre, p.descripcion, p.usuario_id, p.fecha_creacion,
                       p.adoptado_por_id, p.visitas,
                       CONCAT(u.nombre, ' ', u.apellido) AS donador,
                       CONCAT(a.nombre, ' ', a.apellido) AS adoptante
                FROM peluches p
                JOIN usuarios u ON u.id = p.usuario_id
                LEFT JOIN usuarios a ON a.id = p.adoptado_por_id
                WHERE p.id = %(id)s
                LIMIT 1
            """
            resultados = conexion.query_db(consulta, {"id": peluche_id})
            if not resultados:
                return None
            return cls(resultados[0])
        finally:
            conexion.connection.close()

    @classmethod
    def crear(cls, datos, usuario_id):
        valores = cls._limpiar_datos(datos)
        valores["usuario_id"] = usuario_id
        consulta = """
            INSERT INTO peluches (nombre, descripcion, usuario_id)
            VALUES (%(nombre)s, %(descripcion)s, %(usuario_id)s)
        """
        return cls._ejecutar_consulta(consulta, valores)

    @classmethod
    def actualizar(cls, peluche_id, usuario_id, datos):
        valores = cls._limpiar_datos(datos)
        valores["id"] = peluche_id
        valores["usuario_id"] = usuario_id
        consulta = """
            UPDATE peluches
            SET nombre = %(nombre)s, descripcion = %(descripcion)s
            WHERE id = %(id)s AND usuario_id = %(usuario_id)s
        """
        return cls._ejecutar_consulta(consulta, valores)

    @classmethod
    def borrar(cls, peluche_id, usuario_id):
        # Esta condición impide borrar la donación de otra persona.
        consulta = """
            DELETE FROM peluches
            WHERE id = %(id)s AND usuario_id = %(usuario_id)s
        """
        valores = {"id": peluche_id, "usuario_id": usuario_id}
        return cls._ejecutar_consulta(consulta, valores)

    @classmethod
    def adoptar(cls, peluche_id, usuario_id):
        # Solo se adopta si aún está disponible y no es una donación propia.
        consulta = """
            UPDATE peluches
            SET adoptado_por_id = %(usuario_id)s
            WHERE id = %(id)s
              AND usuario_id <> %(usuario_id)s
              AND adoptado_por_id IS NULL
        """
        valores = {"id": peluche_id, "usuario_id": usuario_id}
        return cls._ejecutar_consulta(consulta, valores)

    @staticmethod
    def validar(datos):
        errores = []
        nombre = (datos.get("nombre") or "").strip()
        descripcion = (datos.get("descripcion") or "").strip()

        # Revisamos que ambos campos tengan contenido y no sean demasiado largos.
        if not nombre:
            errores.append("El nombre del peluche no puede estar vacío.")
        elif len(nombre) > _MAX_NOMBRE_LENGTH:
            errores.append("El nombre del peluche no puede superar los 120 caracteres.")

        if not descripcion:
            errores.append("La descripción no puede estar vacía.")
        elif len(descripcion) > _MAX_DESCRIPCION_LENGTH:
            errores.append("La descripción no puede superar los 5000 caracteres.")

        return errores
