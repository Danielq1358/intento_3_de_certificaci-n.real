import os
from pathlib import Path

import pymysql
from pymysql.cursors import DictCursor
from dotenv import load_dotenv


# Buscamos .env en la carpeta principal del proyecto.
load_dotenv(Path(__file__).resolve().parents[2] / ".env")


class Config:
    # Opciones básicas que Flask necesita para iniciar la aplicación.
    SECRET_KEY = os.environ.get("SECRET_KEY")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"


class MySQLConnection:
    def __init__(self, db=None):
        # Leemos los datos de conexión. MYSQL_* se conserva para configuraciones antiguas.
        host = os.getenv("DB_HOST") or os.getenv("MYSQL_HOST", "localhost")
        usuario = os.getenv("DB_USER") or os.getenv("MYSQL_USER", "root")
        puerto = os.getenv("DB_PORT") or os.getenv("MYSQL_PORT", "3306")
        nombre_base_datos = (
            db
            or os.getenv("DB_NAME")
            or os.getenv("MYSQL_DATABASE", "donacion_peluches")
        )

        contrasena = os.getenv("DB_PASSWORD")
        if contrasena is None:
            contrasena = os.getenv("MYSQL_PASSWORD", "")

        # Abrimos la conexión y pedimos que cada fila venga como diccionario.
        self.connection = pymysql.connect(
            host=host,
            user=usuario,
            password=contrasena,
            db=nombre_base_datos,
            port=int(puerto),
            charset="utf8mb4",
            cursorclass=DictCursor,
            autocommit=True,
        )

    def query_db(self, query, data=None):
        # Enviamos los valores por separado para que la consulta sea segura.
        with self.connection.cursor() as cursor:
            cursor.execute(query, data or {})

            # SELECT devuelve filas; INSERT devuelve el id nuevo; otras consultas,
            # como UPDATE y DELETE, devuelven cuántas filas cambiaron.
            if cursor.description:
                return cursor.fetchall()
            if query.lstrip().lower().startswith("insert"):
                return cursor.lastrowid
            return cursor.rowcount


def connectToMySQL(db=None):
    # Creamos una conexión, usando la base de datos indicada si se recibió una.
    return MySQLConnection(db)


# Alias para que también funcionen las llamadas con el nombre anterior.
connect_to_mysql = connectToMySQL
